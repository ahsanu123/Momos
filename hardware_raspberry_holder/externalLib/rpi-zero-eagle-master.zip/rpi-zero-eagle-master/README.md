# rpi-zero-eagle

![alt tag](http://i.imgur.com/KBWR9wd.png)

![alt tag](http://i.imgur.com/6VUIk5U.png)

This is an Eagle library containing the footprint of Raspberry Pi Zero with bottom pads.
